# Interne Richtlinie & Verfahrensordnung zum Hinweisgeberschutz (§§ 12–18 HinSchG / EU-RL 2019/1937)

**Unternehmen:** [Firmenname GmbH]  
**Meldestellen-Beauftragte(r) (§ 15 HinSchG):** [Name / Externe Ombudsstelle]  
**Vertraulicher Meldekanal:** [meldestelle@ihre-domain.de / Telefon / Persönliches Gespräch]  
**Stand:** 2026

## § 1 Zielsetzung und Geltungsbereich
Diese Richtlinie regelt das Verfahren für vertrauliche Meldungen über Rechts- und Regelverstöße im Sinne des § 2 Hinweisgeberschutzgesetz (HinSchG) durch Beschäftigte, Auszubildende, Bewerbende, Organmitglieder sowie externe Dienstleister und Lieferanten.

## § 2 Vertraulichkeitsgebot (§ 8 HinSchG)
Die Identität der hinweisgebenden Person sowie der Personen, die Gegenstand einer Meldung sind, wird streng vertraulich behandelt. Zugriff auf eingehende Meldungen haben ausschließlich die ausdrücklich nach § 15 Abs. 1 HinSchG betrauten, unabhängig handelnden und geschulten Meldestellen-Beauftragten.

## § 3 Meldewege (schriftlich, mündlich, persönlich)
Meldungen können gemäß § 16 Abs. 3 HinSchG in Textform, telefonisch oder auf Wunsch der hinweisgebenden Person innerhalb einer angemessenen Frist in einer persönlichen Zusammenkunft (auch per Videokonferenz) abgegeben werden.

## § 4 Gesetzlicher Verfahrensablauf & Fristen (§ 17 HinSchG)
1. **Eingangsbestätigung binnen 7 Tagen (§ 17 Abs. 1 Nr. 1 HinSchG):** Spätestens nach 7 Kalendertagen erhält die hinweisgebende Person eine schriftliche Eingangsbestätigung.
2. **Stichhaltigkeitsprüfung & Kontakt (§ 17 Abs. 1 Nr. 2–5 HinSchG):** Die Meldestelle prüft, ob der gemeldete Verstoß in den sachlichen Anwendungsbereich nach § 2 HinSchG fällt und stichhaltig ist, hält Kontakt mit der hinweisgebenden Person und ergreift geeignete Folgemaßnahmen nach § 18 HinSchG.
3. **Qualifizierte Rückmeldung binnen 3 Monaten (§ 17 Abs. 2 HinSchG):** Innerhalb von spätestens 3 Monaten nach der Bestätigung des Eingangs der Meldung erhält die hinweisgebende Person eine Rückmeldung über geplante sowie bereits ergriffene Folgemaßnahmen und die Gründe für diese.

## § 5 Verbot von Repressalien (§ 36 HinSchG)
Jede Form von Benachteiligung, Kündigung, Abmahnung oder Einschüchterung gegenüber redlich hinweisgebenden Personen ist gesetzlich verboten; es gilt die Beweislastumkehr nach § 36 Abs. 2 HinSchG.

## § 6 Dokumentation & Löschfrist (§ 11 HinSchG)
Alle Meldungen werden unter Wahrung der Vertraulichkeit dokumentiert und gemäß § 11 Abs. 5 HinSchG **3 Jahre nach Abschluss des Verfahrens** gelöscht, sofern keine längere Aufbewahrung zur Erfüllung gesetzlicher Anforderungen erforderlich und verhältnismäßig ist.

## § 7 Hinweis auf externe Meldestellen (§ 13 Abs. 2 HinSchG)
Hinweisgebende Personen haben jederzeit auch die Möglichkeit, sich an eine externe Meldestelle des Bundes (Bundesamt für Justiz – BfJ, BaFin oder Bundeskartellamt) zu wenden; die Nutzung der internen Meldestelle wird zur schnellen unmittelbaren Abhilfe ausdrücklich begrüßt (§ 7 Abs. 1 HinSchG).
