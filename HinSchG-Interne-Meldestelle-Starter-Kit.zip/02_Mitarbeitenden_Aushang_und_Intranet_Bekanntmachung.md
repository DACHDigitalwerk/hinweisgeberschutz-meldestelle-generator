# Bekanntmachung für Mitarbeitende (Intranet / Schwarzes Brett) gemäß § 13 Abs. 2 HinSchG

## Einrichtung unserer Internen Meldestelle nach dem Hinweisgeberschutzgesetz (HinSchG)

Liebe Mitarbeiterinnen und Mitarbeiter,

integres und rechtskonformes Handeln bildet die Grundlage unseres Erfolgs. Gemäß §§ 12 ff. Hinweisgeberschutzgesetz (HinSchG) haben wir eine **vertrauliche interne Meldestelle** eingerichtet, an die Sie sich jederzeit wenden können, wenn Sie im Zusammenhang mit Ihrer beruflichen Tätigkeit konkrete Hinweise auf Straftaten, bußgeldbewehrte Verstöße (z. B. Arbeitsschutz, Mindestlohn, Datenschutz, Produktsicherheit, Umweltrecht) oder sonstige unter § 2 HinSchG fallende Rechtsverstöße erhalten.

### Ihre vertraulichen Kontaktwege:
- **Vertraulicher Meldekanal (Textform):** `[meldestelle@ihre-domain.de]`
- **Mündlich / Persönliches Gespräch (§ 16 Abs. 3 HinSchG):** `[Telefonnummer / Terminvereinbarung]`
- **Zuständige(r) Meldestellen-Beauftragte(r):** `[Name / Ombudsperson]`

### Unser Schutzversprechen an Sie:
1. **Strenge Vertraulichkeit (§ 8 HinSchG):** Ihre Identität wird geschützt und ist ausschließlich der beauftragten Meldestelle bekannt.
2. **Verbindliche Fristen (§ 17 HinSchG):** Sie erhalten spätestens innerhalb von **7 Tagen** eine Eingangsbestätigung und innerhalb von spätestens **3 Monaten** eine inhaltliche Rückmeldung zu den ergriffenen Maßnahmen.
3. **Schutz vor Benachteiligung (§ 36 HinSchG):** Redliche Hinweisgebende sind gesetzlich umfassend vor jeglichen arbeitsrechtlichen Nachteilen oder Repressalien geschützt.

Ergänzend weisen wir gemäß § 13 Abs. 2 HinSchG darauf hin, dass neben unserer internen Meldestelle auch staatliche externe Meldestellen (insbesondere beim Bundesamt für Justiz unter `www.bundesjustizamt.de`, bei der BaFin sowie beim Bundeskartellamt) bestehen. Wir ermutigen Sie jedoch ausdrücklich, Hinweise zunächst intern zu melden, damit wir Missstände unmittelbar und unbürokratisch abstellen können.

**[Ort, Datum] — Die Geschäftsführung**
