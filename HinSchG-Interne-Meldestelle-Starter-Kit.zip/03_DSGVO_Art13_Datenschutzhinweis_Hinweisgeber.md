# Datenschutzinformation gemäß Art. 13 und Art. 14 DSGVO für das Hinweisgebersystem (§ 10 HinSchG)

**1. Verantwortlicher (Art. 4 Nr. 7 DSGVO):**  
[Firmenname GmbH, Anschrift, E-Mail]

**2. Zwecke und Rechtsgrundlage der Verarbeitung:**  
Die Verarbeitung personenbezogener Daten im Rahmen der Entgegennahme, Stichhaltigkeitsprüfung und Aufklärung von Hinweisen sowie der Durchführung von Folgemaßnahmen erfolgt zur Erfüllung einer rechtlichen Verpflichtung gemäß **Art. 6 Abs. 1 lit. c DSGVO i. V. m. § 10, §§ 12–18 HinSchG** (für besondere Kategorien personenbezogener Daten gem. Art. 9 Abs. 2 lit. g DSGVO i. V. m. § 10 Satz 2 HinSchG).

**3. Strenge Zugriffsbeschränkung & Vertraulichkeit (§ 8 HinSchG):**  
Auf die Meldedaten haben ausschließlich die nach § 15 HinSchG benannten, zur Verschwiegenheit verpflichteten Beauftragten der internen Meldestelle Zugriff. Eine Weitergabe der Identität erfolgt nur in den engen gesetzlichen Ausnahmefällen des § 9 HinSchG.

**4. Speicherdauer & Löschfrist (§ 11 Abs. 5 HinSchG):**  
Die Dokumentation einer Meldung wird **3 Jahre nach Abschluss des Verfahrens** gelöscht. Sie kann länger aufbewahrt werden, um die Anforderungen nach dem HinSchG oder nach anderen Rechtsvorschriften zu erfüllen, solange dies erforderlich und verhältnismäßig ist.

**5. Betroffenenrechte (Art. 15–21 DSGVO):**  
Betroffene Personen haben im Rahmen der gesetzlichen Vorgaben (unter Beachtung des vorrangigen Identitätsschutzes der hinweisgebenden Person nach § 8 HinSchG und § 29 BDSG) das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung sowie Beschwerde bei einer Datenschutzaufsichtsbehörde.
