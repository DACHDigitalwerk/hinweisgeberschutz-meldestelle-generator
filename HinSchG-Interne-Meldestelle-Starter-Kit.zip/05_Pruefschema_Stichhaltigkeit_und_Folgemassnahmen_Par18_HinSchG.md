# Prüfschema für Meldestellen-Beauftragte (§§ 17, 18 HinSchG)

1. **Tag 0 (Eingang):** Fall-ID vergeben, Zugriff auf berechtigte Person nach § 15 HinSchG beschränken, Fristen (Tag +7 und Monat +3) im Register eintragen.
2. **Bis spätestens Tag 7 (§ 17 Abs. 1 Nr. 1 HinSchG):** Eingangsbestätigung an hinweisgebende Person übermitteln (sofern Kontaktweg vorhanden).
3. **Formale & Materielle Vorprüfung (§ 17 Abs. 1 Nr. 2 & 3 HinSchG):**
   - Fällt der Sachverhalt unter § 2 HinSchG (Strafrecht, bußgeldbewehrte Arbeitsschutz-/Umwelt-/DSGVO-/Mindestlohn-Vorschriften, EU-Rechtsakte)?
   - Liegen hinreichende tatsächliche Anhaltspunkte (Stichhaltigkeit) vor oder sind Rückfragen nach § 17 Abs. 1 Nr. 4 HinSchG erforderlich?
4. **Folgemaßnahmen (§ 18 HinSchG):**
   - Nr. 1: Interne Untersuchungen durchführen und betroffene Stellen/Personen kontaktieren (unter strikter Wahrung von § 8 HinSchG!).
   - Nr. 2: Verweisung der hinweisgebenden Person an andere zuständige Stellen.
   - Nr. 3: Abschluss des Verfahrens aus Mangel an Beweisen oder aus anderen Gründen.
   - Nr. 4: Abgabe des Verfahrens zwecks weiterer Untersuchungen an eine für interne Ermittlungen zuständige Arbeitseinheit oder an eine zuständige Behörde.
5. **Bis spätestens 3 Monate nach Eingangsbestätigung (§ 17 Abs. 2 HinSchG):** Schriftliche Rückmeldung an die hinweisgebende Person über geplante und bereits ergriffene Folgemaßnahmen sowie die Gründe hierfür.
6. **Abschluss & Löschvormerkung (§ 11 Abs. 5 HinSchG):** Löschdatum exakt 3 Jahre nach Verfahrensabschluss eintragen.
